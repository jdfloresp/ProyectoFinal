package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.CuentDelegateImp;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import com.nttdata.microstransacciones.model.entity.Cuent;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CuentTests {

    @InjectMocks
    public CuentMapper cuentMapper;
    public CuentService cuentService;
    public CuentDelegateImp cuentDelegateImp;
    public CuentServiceImp cuentServiceImp;

    @Test
    @DisplayName("Registro de cuenta ok")
    void cuandoRetornaunaCuentaOk() {
        CuentaRequest response = new CuentaRequest();
        response.setCuentaid("Pedro");
        response.setDatosCliente("Torres");
        response.setNumCuenta("34127865");
        response.setSaldo(1000);
        response.setTipoCuenta("1");


        Cuent result =  cuentMapper.getCuentaEntity(response);

        assertNotNull(result);
        assertEquals(response.getCuentaid(),result.getCuentaid());
        assertEquals(response.getDatosCliente(),result.getDatosCliente());
        assertEquals(response.getNumCuenta(),result.getNumCuenta());
        assertEquals(response.getSaldo(),result.getSaldo());


    }




}
