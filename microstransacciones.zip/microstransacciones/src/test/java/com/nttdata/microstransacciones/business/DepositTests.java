package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.business.deposito.DepositMapper;
import com.nttdata.microstransacciones.model.DepositoResponse;
import com.nttdata.microstransacciones.model.entity.Deposit;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class DepositTests {

    @InjectMocks
    public DepositMapper depositMapper;

    @Test
    @DisplayName("Registro de deposito ok")
    void cuandoDepositoOk() {
        DepositoResponse response = new DepositoResponse();
        response.setMontoDeposito(1500);
        response.setCuentaDeposito("453212678");
        //response.setTipoMovimiento("DEPOSITO");


        Deposit result =  depositMapper.getDepositoEntity(response);

        assertNotNull(result);
        assertEquals(response.getMontoDeposito(),result.getMontoDeposito());
        assertEquals(response.getCuentaDeposito(),result.getCuentaDeposito());
        //assertEquals(response.getTipoMovimiento(),result.getTipoMovimiento());

    }
}
