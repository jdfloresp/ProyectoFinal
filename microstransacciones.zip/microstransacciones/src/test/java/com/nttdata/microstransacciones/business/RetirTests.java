package com.nttdata.microstransacciones.business;

import com.nttdata.microstransacciones.business.retiro.RetirMapper;
import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.entity.Retir;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RetirTests {

    @InjectMocks
    public RetirMapper retirMapper;

    @Test
    @DisplayName("Registro de retiro ok")
    void cuandoRetiroOk() {
        RetiroRequest response = new RetiroRequest();
        response.setMontoRetiro(2000);
        response.setCuentaRetiro("453212678");
        //response.setTipoMovimiento("RETIRO");


        Retir result =  retirMapper.getRetiroEntity(response);

        assertNotNull(result);
        assertEquals(response.getMontoRetiro(),result.getMontoRetiro());
        assertEquals(response.getCuentaRetiro(),result.getCuentaRetiro());
        //assertEquals(response.getTipoMovimiento(),result.getTipoMovimiento());

    }
}
