package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.business.deposito.DepositMapper;
import com.nttdata.microstransacciones.business.transferencia.TransferMapper;
import com.nttdata.microstransacciones.model.DepositoResponse;
import com.nttdata.microstransacciones.model.TransferenciaResponse;
import com.nttdata.microstransacciones.model.entity.Deposit;
import com.nttdata.microstransacciones.model.entity.Transfer;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class TransferTests {

    @InjectMocks
    public TransferMapper transferMapper;

    @Test
    @DisplayName("Registro de transferencia ok")
    void cuandoTransferenciaOk() {
        TransferenciaResponse response = new TransferenciaResponse();
        response.setMontoTransferencia(1500);
        response.setCuentaOrigen("453212678");
        response.setCuentaDestino("12345678");
        //response.setTipoMovimiento("TRANSFERENCIA");


        Transfer result =  transferMapper.getTransferenciaEntity(response);

        assertNotNull(result);
        assertEquals(response.getMontoTransferencia(),result.getMontoTransferencia());
        assertEquals(response.getCuentaOrigen(),result.getCuentaOrigen());
        assertEquals(response.getCuentaDestino(),result.getCuentaDestino());
        //assertEquals(response.getTipoMovimiento(),result.getTipoMovimiento());

    }
}
