package com.nttdata.microstransacciones;

import com.nttdata.microstransacciones.business.*;
import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import com.nttdata.microstransacciones.model.entity.Cuent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.*;import static org.mockito.Mockito.when;



@ExtendWith(MockitoExtension.class)
class MicrostransaccionesApplicationTests {


}
