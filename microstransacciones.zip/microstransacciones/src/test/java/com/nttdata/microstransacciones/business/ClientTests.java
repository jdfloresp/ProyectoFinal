package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.CuentDelegateImp;
import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.entity.Client;
import com.nttdata.microstransacciones.repository.ClientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import reactor.core.publisher.Flux;

@ExtendWith(MockitoExtension.class)
public class ClientTests {

    @InjectMocks
    public ClientMapper clientMapper;
    public ClientService clientService;
    public ClientServiceImp clientServiceImp;
    public ClientRepository clientRepository;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Registro de cliente ok")
    void cuandoRetornaClienteOk() {
        ClienteRequest response = new ClienteRequest();
        response.setNombres("Pedro");
        response.setApellidos("Torres");
        response.setDni("34127865");
        response.setEmail("pedro_t@gmail.com");
        response.setClienteid("1");

        Client result =  clientMapper.getClienteEntity(response);

        assertNotNull(result);
        assertEquals(response.getApellidos(),result.getApellidos());
        assertEquals(response.getNombres(),result.getNombres());
        assertEquals(response.getDni(),result.getDni());
        assertEquals(response.getEmail(),result.getEmail());
        assertEquals(response.getClienteid(),result.getClienteid());

    }



}
