package com.nttdata.microstransacciones.repository;


import com.nttdata.microstransacciones.model.entity.Retir;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RetirRepository extends MongoRepository<Retir,String> {
}
