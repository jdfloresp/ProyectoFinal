package com.nttdata.microstransacciones.business.retiro;


import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.RetiroResponse;
import com.nttdata.microstransacciones.repository.RetirRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RetirServiceImp implements RetirService{

    @Autowired
    RetirRepository retirRepository;

    @Autowired
    RetirMapper retirMapper;

    @Override
    public RetiroResponse registerRetiro(RetiroRequest retiroRequest) {
        return retirMapper
                .getRetiroResponse(retirRepository.save(retirMapper.getRetiroEntity(retiroRequest)));
    }

    @Override
    public List<RetiroResponse> listRetiros() {
        return retirRepository.findAll().stream()
                .map(m->retirMapper.getRetiroResponse(m))
                .collect(Collectors.toList());
    }
}
