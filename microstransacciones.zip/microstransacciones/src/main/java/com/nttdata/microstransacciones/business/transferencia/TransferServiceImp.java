package com.nttdata.microstransacciones.business.transferencia;


import com.nttdata.microstransacciones.model.TransferenciaResponse;
import com.nttdata.microstransacciones.repository.TransferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransferServiceImp implements TransferService{

    @Autowired
    TransferRepository transferRepository;

    @Autowired
    TransferMapper transferMapper;

    @Override
    public TransferenciaResponse registerTransferencia(TransferenciaResponse transferenciaResponse) {
        return transferMapper
                .getTransferenciaResponse(transferRepository.save(transferMapper.getTransferenciaEntity(transferenciaResponse)));
    }

    @Override
    public List<TransferenciaResponse> listTransferencias() {
        return transferRepository.findAll().stream()
                .map(m->transferMapper.getTransferenciaResponse(m))
                .collect(Collectors.toList());
    }
}
