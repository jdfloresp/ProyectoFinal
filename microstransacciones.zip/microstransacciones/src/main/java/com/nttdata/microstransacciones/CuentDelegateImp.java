package com.nttdata.microstransacciones;


import com.nttdata.microstransacciones.api.CuentaApiDelegate;
import com.nttdata.microstransacciones.business.CuentService;
import com.nttdata.microstransacciones.model.CuentaRequest;
import com.nttdata.microstransacciones.model.CuentaResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CuentDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentService cuentService;

    @Override
    public ResponseEntity<List<CuentaResponse>> listCuentas() {
        return ResponseEntity.ok(cuentService.listCuentas());
    }

    @Override
    public ResponseEntity<CuentaResponse> registerCuenta(CuentaRequest cuentaRequest) {
        return ResponseEntity.ok(cuentService.registerCuenta(cuentaRequest));
    }
}
