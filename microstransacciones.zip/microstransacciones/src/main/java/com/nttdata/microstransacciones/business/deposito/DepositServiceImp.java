package com.nttdata.microstransacciones.business.deposito;


import com.nttdata.microstransacciones.model.DepositoResponse;
import com.nttdata.microstransacciones.repository.DepositRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepositServiceImp implements DepositService{

    @Autowired
    DepositRepository depositRepository;

    @Autowired
    DepositMapper depositMapper;

    @Override
    public DepositoResponse registerDeposito(DepositoResponse depositoResponse) {
        return depositMapper
                .getDepositoResponse(depositRepository.save(depositMapper.getDepositoEntity(depositoResponse)));
    }

    @Override
    public List<DepositoResponse> listDepositos() {
        return depositRepository.findAll().stream()
                .map(m->depositMapper.getDepositoResponse(m))
                .collect(Collectors.toList());
    }
}
