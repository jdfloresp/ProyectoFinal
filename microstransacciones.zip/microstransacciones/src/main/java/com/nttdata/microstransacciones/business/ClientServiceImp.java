package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import com.nttdata.microstransacciones.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClientServiceImp implements ClientService{

@Autowired
    ClientRepository clientRepository;

@Autowired
    ClientMapper clientMapper;


//registrar cliente///
    @Override
    public ClienteResponse registerCliente(ClienteRequest clienteRequest) {
        return clientMapper
                .getClienteResponse(clientRepository.save(clientMapper.getClienteEntity(clienteRequest)));
    }

    //listar cliente//
    @Override
    public List<ClienteResponse> listClientes() {
        return clientRepository.findAll().stream()
                .map(m->clientMapper.getClienteResponse(m))
                .collect(Collectors.toList());
    }


}
