package com.nttdata.microstransacciones.model.entity;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Data
@Document(collection = "deposito")
public class Deposit {

    @Id
    private String Depositoid;
    private Integer montoDeposito;
    private String cuentaDeposito;
    private String tipoMovimiento;
}
