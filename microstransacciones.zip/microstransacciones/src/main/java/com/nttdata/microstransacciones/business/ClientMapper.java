package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import org.springframework.data.mongodb.core.aggregation.ConvertOperators;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;


@Component
public class ClientMapper {


    //registrar usuario
    public Client getClienteEntity(ClienteRequest request){
        Client entity = new Client();
        entity.setClienteid(request.getClienteid());
        entity.setNombres(request.getNombres());
        entity.setApellidos(request.getApellidos());
        entity.setDni(request.getDni());
        entity.setEmail(request.getEmail());
        return entity;

    }

    //listar cliente//
    public ClienteResponse getClienteResponse(Client entity){
        ClienteResponse response = new ClienteResponse();
        response.setClienteid(entity.getClienteid());
        response.setApellidos(entity.getApellidos());
        response.setNombres(entity.getNombres());
        response.setDni(entity.getDni());
        response.setEmail(entity.getEmail());
        return response;

    }


}
