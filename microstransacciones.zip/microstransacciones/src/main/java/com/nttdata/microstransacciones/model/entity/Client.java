package com.nttdata.microstransacciones.model.entity;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;


@Data
@Document (collection = "cliente")
public class Client{
    @Id
    private String Clienteid;
    private String Nombres;
    private String Apellidos;
    private String Dni;
    private String Email;
    //private String Fecha;
}
