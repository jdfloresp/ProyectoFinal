package com.nttdata.microstransacciones;

import com.nttdata.microstransacciones.api.TransacciontransferenciaApiDelegate;
import com.nttdata.microstransacciones.business.transferencia.TransferService;
import com.nttdata.microstransacciones.model.TransferenciaResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransferDelegateImp implements TransacciontransferenciaApiDelegate {

    @Autowired
    TransferService transferService;


    @Override
    public ResponseEntity<List<TransferenciaResponse>> listTransferencias() {
        return ResponseEntity.ok(transferService.listTransferencias());
    }

    @Override
    public ResponseEntity<TransferenciaResponse> registerTransferencia(TransferenciaResponse transferenciaResponse) {
        transferenciaResponse.setTipoMovimiento("TRANSFERENCIA");
        return ResponseEntity.ok(transferService.registerTransferencia(transferenciaResponse));
    }
}
