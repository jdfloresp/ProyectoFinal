package com.nttdata.microstransacciones.business;


import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import io.swagger.models.auth.In;

import java.util.List;
import java.util.Optional;

public interface ClientService {

    public ClienteResponse registerCliente(ClienteRequest clienteRequest) ;

    List<ClienteResponse> listClientes();


}
