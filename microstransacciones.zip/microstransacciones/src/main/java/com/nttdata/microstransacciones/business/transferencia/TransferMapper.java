package com.nttdata.microstransacciones.business.transferencia;

import com.nttdata.microstransacciones.model.TransferenciaResponse;
import com.nttdata.microstransacciones.model.entity.Transfer;
import org.springframework.stereotype.Component;

@Component
public class TransferMapper {

    //registrar transferencia
    public Transfer getTransferenciaEntity(TransferenciaResponse response){
        Transfer entity = new Transfer();
        entity.setTransferenciaid(response.getTransferenciaid());
        entity.setMontoTransferencia(response.getMontoTransferencia());
        entity.setCuentaOrigen(response.getCuentaOrigen());
        entity.setCuentaDestino(response.getCuentaDestino());
        entity.setTipoMovimiento(response.getTipoMovimiento());
        return entity;
    }

    //listar transferencias//
    public TransferenciaResponse getTransferenciaResponse(Transfer entity){
        TransferenciaResponse response = new TransferenciaResponse();
        response.setTransferenciaid(entity.getTransferenciaid());
        response.setMontoTransferencia(entity.getMontoTransferencia());
        response.setCuentaOrigen(entity.getCuentaOrigen());
        response.setCuentaDestino(entity.getCuentaDestino());
        response.setTipoMovimiento(entity.getTipoMovimiento());
        return response;

    }

}
