package com.nttdata.microstransacciones;

import com.nttdata.microstransacciones.api.TransaccionretiroApiDelegate;
import com.nttdata.microstransacciones.business.CuentService;
import com.nttdata.microstransacciones.business.retiro.RetirService;
import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.RetiroResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RetirDelegateImp implements TransaccionretiroApiDelegate {

    @Autowired

    RetirService retirService;

    @Override
    public ResponseEntity<List<RetiroResponse>> listRetiros() {
        return ResponseEntity.ok(retirService.listRetiros());
    }

    @Override
    public ResponseEntity<RetiroResponse> registerRetiro(RetiroRequest retiroRequest) {
        retiroRequest.setTipoMovimiento("RETIRO");
        return ResponseEntity.ok(retirService.registerRetiro(retiroRequest));
    }



}
