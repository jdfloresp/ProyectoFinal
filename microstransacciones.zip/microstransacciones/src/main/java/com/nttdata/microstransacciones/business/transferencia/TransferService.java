package com.nttdata.microstransacciones.business.transferencia;


import com.nttdata.microstransacciones.model.TransferenciaResponse;

import java.util.List;

public interface TransferService {

    public TransferenciaResponse registerTransferencia(TransferenciaResponse transferenciaResponse) ;

    List<TransferenciaResponse> listTransferencias();
}
