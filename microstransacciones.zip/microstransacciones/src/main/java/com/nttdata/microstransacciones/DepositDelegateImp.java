package com.nttdata.microstransacciones;



import com.nttdata.microstransacciones.api.TransacciondepositoApiDelegate;
import com.nttdata.microstransacciones.business.deposito.DepositService;
import com.nttdata.microstransacciones.model.DepositoResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepositDelegateImp implements TransacciondepositoApiDelegate {

    @Autowired
    DepositService depositService;

    @Override
    public ResponseEntity<List<DepositoResponse>> listDepositos() {
        return ResponseEntity.ok(depositService.listDepositos());
    }

    @Override
    public ResponseEntity<DepositoResponse> registerDeposito(DepositoResponse depositoResponse) {
        depositoResponse.setTipoMovimiento("DEPOSITO");
        return ResponseEntity.ok(depositService.registerDeposito(depositoResponse));
    }

}
