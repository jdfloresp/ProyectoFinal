package com.nttdata.microstransacciones.repository;

import com.nttdata.microstransacciones.model.entity.Cuent;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CuentRepository extends MongoRepository<Cuent ,String> {
}
