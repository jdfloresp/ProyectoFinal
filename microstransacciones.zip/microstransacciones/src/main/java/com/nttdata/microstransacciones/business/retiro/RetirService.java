package com.nttdata.microstransacciones.business.retiro;

import com.nttdata.microstransacciones.model.RetiroResponse;
import com.nttdata.microstransacciones.model.RetiroRequest;

import java.util.List;
import java.util.Optional;

public interface RetirService {


    public RetiroResponse registerRetiro(RetiroRequest retiroRequest) ;

    List<RetiroResponse> listRetiros();

}
