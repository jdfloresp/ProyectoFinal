package com.nttdata.microstransacciones;


import com.nttdata.microstransacciones.api.ClienteApiDelegate;
import com.nttdata.microstransacciones.business.ClientService;
import com.nttdata.microstransacciones.model.ClienteRequest;
import com.nttdata.microstransacciones.model.ClienteResponse;
import com.nttdata.microstransacciones.model.entity.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Service
public class ClientDelegateImp implements ClienteApiDelegate {

    @Autowired
    ClientService clientService;


    //registrar cliente//
    @Override
    public ResponseEntity<ClienteResponse> registerCliente(ClienteRequest clienteRequest) {
        return ResponseEntity.ok(clientService.registerCliente(clienteRequest));
    }


    //listar los clientes//
    @Override
    public ResponseEntity<List<ClienteResponse>> listClientes() {
        return ResponseEntity.ok(clientService.listClientes());
    }


}
