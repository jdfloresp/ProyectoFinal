package com.nttdata.microstransacciones.business.deposito;

import com.nttdata.microstransacciones.model.DepositoResponse;
import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.RetiroResponse;
import com.nttdata.microstransacciones.model.entity.Deposit;
import org.springframework.stereotype.Component;


@Component
public class DepositMapper {

    //registrar usuario
    public Deposit getDepositoEntity(DepositoResponse response){
        Deposit entity = new Deposit();
        entity.setDepositoid(response.getDepositoid());
        entity.setMontoDeposito(response.getMontoDeposito());
        entity.setCuentaDeposito(response.getCuentaDeposito());
        entity.setTipoMovimiento(response.getTipoMovimiento());
        return entity;
    }

    //listar cliente//
    public DepositoResponse getDepositoResponse(Deposit entity){
        DepositoResponse response = new DepositoResponse();
        response.setDepositoid(entity.getDepositoid());
        response.setMontoDeposito(entity.getMontoDeposito());
        response.setCuentaDeposito(entity.getCuentaDeposito());
        response.setTipoMovimiento(entity.getTipoMovimiento());
        return response;

    }
}
