package com.nttdata.microstransacciones.model.entity;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@Document (collection = "transferencia")
public class Transfer {

    @Id
    private String Transferenciaid;
    private Integer montoTransferencia;
    private String cuentaOrigen;
    private String cuentaDestino;
    private String tipoMovimiento;

}
