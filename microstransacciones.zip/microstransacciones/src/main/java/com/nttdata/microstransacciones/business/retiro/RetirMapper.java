package com.nttdata.microstransacciones.business.retiro;


import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.RetiroResponse;
import com.nttdata.microstransacciones.model.entity.Retir;
import org.springframework.stereotype.Component;

@Component
public class RetirMapper {

    //registrar usuario
    public Retir getRetiroEntity(RetiroRequest request){
        Retir entity = new Retir();
        entity.setRetiroid(request.getRetiroid());
        entity.setMontoRetiro(request.getMontoRetiro());
        entity.setTipoMovimiento(request.getTipoMovimiento());
        entity.setCuentaRetiro(request.getCuentaRetiro());
        return entity;
    }

    //listar cliente//
    public RetiroResponse getRetiroResponse(Retir entity){
        RetiroResponse response = new RetiroResponse();
        response.setRetiroid(entity.getRetiroid());
        response.setMontoRetiro(entity.getMontoRetiro());
        response.setTipoMovimiento(entity.getTipoMovimiento());
        response.setCuentaRetiro(entity.getCuentaRetiro());
        return response;

    }

}
