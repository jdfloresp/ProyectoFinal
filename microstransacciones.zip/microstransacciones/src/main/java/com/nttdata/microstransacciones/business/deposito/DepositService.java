package com.nttdata.microstransacciones.business.deposito;


import com.nttdata.microstransacciones.model.DepositoResponse;
import com.nttdata.microstransacciones.model.RetiroRequest;
import com.nttdata.microstransacciones.model.RetiroResponse;

import java.util.List;

public interface DepositService {

    public DepositoResponse registerDeposito(DepositoResponse depositoResponse) ;

    List<DepositoResponse> listDepositos();

}
